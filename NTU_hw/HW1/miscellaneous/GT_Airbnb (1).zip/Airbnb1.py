#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sns


# # import Airbnb Data

# In[2]:


data = pd.read_csv("AirbnbData.csv")
data.iloc[:10]


# # Drop observations if the locations are duplicated

# In[3]:


print(len(data))
data.drop_duplicates(subset=['lat', 'long'])

print(len(data))


# # Value counts

# In[4]:


Q1 = data['host_identity_verified'].value_counts()
Q1


# In[5]:


left = np.array(["unconfirmed", "verified"])
height = Q1
plt.bar(left, height, color = "k")
plt.show()


# In[6]:


Q2 = data['neighbourhood group'].value_counts()
Q2


# In[7]:


left = np.array(["Manhattan", "Brooklyn", "Queens", "Bronx", "Staten Island"])
height = Q2[:-2]
plt.bar(left, height, color = "k")
plt.show()


# In[8]:


Q3 = data['room type'].value_counts()
Q3 = Q3.div(sum(Q3))
Q3


# In[9]:


for i in Q3:
    print(round(i, 3))


# In[10]:


left = np.array(["Entire home/apt", "Private room", "Shared room", "Hotel room"])
height = Q3
plt.bar(left, height, color = "k")
plt.show()

