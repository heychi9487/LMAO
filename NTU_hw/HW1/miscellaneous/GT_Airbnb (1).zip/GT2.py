#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


# In[2]:


df= pd.read_csv('GlobalTemperatures.csv')
land_ocean = df[['LandAndOceanAverageTemperature']]
land = df[['LandAverageTemperature','LandAverageTemperatureUncertainty']]


# In[3]:


#data preprocessing
newland = land.drop(index = range(0,1212))
newland_ocean = land_ocean.drop(index = range(0,1212))

newland['maximum'] = newland['LandAverageTemperature'] + newland['LandAverageTemperatureUncertainty']
newland['minimum'] = newland['LandAverageTemperature'] - newland['LandAverageTemperatureUncertainty']


# In[4]:


def group_func(index):
    return (index // 120) * 120


# In[5]:


# Group DataFrame by custom groups in every ten years and calculate mean of each group
plt.subplot(2,1,1)
plt.subplots_adjust(hspace=0.8, wspace=0.4)
mean = newland_ocean.groupby(group_func)['LandAndOceanAverageTemperature'].mean().values
x = np.arange(1851,2016,10)
plt.plot(x,mean,'b.-',label = 'mean')
plt.legend()
plt.xlabel('year')
plt.ylabel('Temperature')
plt.ylim(14.5,16.5)
plt.title('Land & Ocean')

plt.subplot(2,1,2)
land = newland.groupby(group_func)['LandAverageTemperature'].mean().values
max = newland.groupby(group_func)['maximum'].mean().values
min = newland.groupby(group_func)['minimum'].mean().values
plt.plot(x,max,'b-',label = 'max')
plt.plot(x,min,'k-',label = 'min')
plt.plot(x,land,'r-',label = 'mean')
plt.title('Land')
plt.xlabel('year')
plt.ylabel('Temperature')
plt.ylim(6.5,10.5)
plt.legend()
plt.show()


# In[6]:


dff = pd.read_csv('GlobalLandTemperaturesByCountry.csv')
ddf = dff.dropna()

ddf['maximum'] = ddf['AverageTemperature']+ddf['AverageTemperatureUncertainty']
ddf['minimum'] = ddf['AverageTemperature']-ddf['AverageTemperatureUncertainty']

group = ddf.groupby('Country').mean()

max_value = group.nlargest(5,['maximum'])
min_value = group.nsmallest(5,['minimum'])


# In[7]:


plt.subplot(2,1,1)
plt.subplots_adjust(hspace=0.8, wspace=0.1)
x = max_value.index
y1 = max_value['maximum']
plt.ylim(28.5,30)
plt.plot(x,y1,'b.-')
plt.title('hottest country')
plt.xlabel('country')
plt.ylabel('Temperature')

plt.subplot(2,1,2)
x2 = min_value.index
y2 = min_value['minimum']

plt.plot(x2,y2,'b.-')
plt.title('coldest country')
plt.xlabel('country')
plt.ylabel('Temperature')
plt.show()


# In[ ]:




