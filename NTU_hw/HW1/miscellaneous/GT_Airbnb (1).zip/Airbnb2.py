#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')


# In[2]:


data=pd.read_csv('AirbnbData.csv')
df = data.copy()


# In[3]:


df['price']=df['price'].str.replace('$',"")
df['service fee']=df['service fee'].str.replace('$',"")
df.drop_duplicates(inplace=True)


# In[4]:


#1
print("Question 1")
print(df['host_identity_verified'].value_counts())
print("The number of empty value:",df['host_identity_verified'].isna().sum())


# In[5]:


#2
print("Question 2")
plt.title('neighbourhood group')
df['neighbourhood group'].value_counts().plot(kind='bar')
plt.xticks(rotation=0)
plt.show()
print(df['neighbourhood group'].value_counts())


# In[6]:


print("Question 3")
room_type_counts = df['room type'].value_counts().to_frame(name='number')
a_all = room_type_counts['number'].sum()
room_type_counts.loc[:,"proportions"] = room_type_counts['number']/a_all
print(room_type_counts)

room_type_counts['proportions'].plot(kind='bar')
plt.title('room types proportions')
plt.xticks(rotation=0)
plt.show()


# In[7]:


#cancellation number and rate
print("Other 1")
cancellation_policy_counts = df['cancellation_policy'].value_counts().to_frame(name='number')
b_all = cancellation_policy_counts['number'].sum()
cancellation_policy_counts.loc[:,"proportions"] = cancellation_policy_counts['number']/b_all
print(cancellation_policy_counts)


# In[8]:


#Construction number for every year 
print("Other 2")
c_counts = df['Construction year'].value_counts().to_frame(name='number').sort_index()
c_all = c_counts['number'].sum()
c_counts.loc[:,"proportions"] = c_counts['number']/c_all
print(c_counts)

c_counts.plot(kind='line', x=df.index.name, y='number', legend=None)
plt.title('Construction year')
plt.show()


# In[9]:


# Repeated host id
print("Other 3")
aa = df[df.duplicated(['host id'],keep=False)]
print(aa)

