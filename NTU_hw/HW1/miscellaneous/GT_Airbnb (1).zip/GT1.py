#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# In[2]:


# 1. Is there a global warming?
temp = pd.read_csv("GlobalTemperatures.csv")
temp.head()


# In[3]:


temp.isna()
temp.replace(' ', np.nan, inplace = True)
temp


# In[5]:


sequence = [num for num in range(1750, 2016) for i in range(12)]
sequence


# In[6]:


temp.insert(0, "Year", sequence, True)
temp


# In[7]:


temp_mean = temp.groupby("Year").agg({"LandAverageTemperature": "mean"})


# In[8]:


temp_mean.reset_index(inplace = True)


# In[9]:


land_avg = temp_mean["LandAverageTemperature"].values.tolist()
thirty_avg = np.mean(land_avg[201:231])
anomalies = temp_mean["LandAverageTemperature"]-thirty_avg
temp_mean.insert(2, "anomalies", anomalies, True)


# In[10]:


plt.style.use("ggplot")
plt.plot("Year", "anomalies", data = temp_mean, color = "red")
plt.suptitle("Land Average Temperature Anomalies, 1750~2015", fontsize = 14)
plt.title("Base Period: 1951~1980", fontsize = 10)
plt.xlabel("Year (C.E.)")
plt.ylabel("Avg. Temp. (deg C)")
plt.savefig("plot1.png", format = "png", dpi = 1200)


# In[11]:


# 2. Which period is the fastest temperature growth?
# See above figure, about after 1980


# In[12]:


# 3. Which country is the hottest one and which is the coldest one?
temp_cty = pd.read_csv("GlobalLandTemperaturesByCountry.csv")
temp_cty.head()


# In[13]:


temp_cty.info()

year_cty = pd.to_datetime(temp_cty["dt"])
year_cty = year_cty.dt.year
temp_cty.insert(0, "Year", year_cty)

year2012_cty = temp_cty[temp_cty["Year"] == 2012]
year2012_cty.head()


# In[14]:


cty_mean_2012 = year2012_cty.groupby("Country").agg({"AverageTemperature": "mean"})
cty_mean_2012.reset_index(inplace = True)


# In[15]:


max_temp = cty_mean_2012["AverageTemperature"].max()
max_cty = cty_mean_2012.loc[max_temp == cty_mean_2012["AverageTemperature"] , "Country"].iloc[0]
min_temp = cty_mean_2012["AverageTemperature"].min()
min_cty = cty_mean_2012.loc[min_temp == cty_mean_2012["AverageTemperature"] , "Country"].iloc[0]


# In[16]:


print(max_cty ,"is the hottest country in terms of 2012 annual average land temperature. The average temperature is", round(max_temp, 2), " degree Celcius.")
print(min_cty ,"is the coldest country in terms of 2012 annual average land temperature. The average temperature is", round(min_temp, 2), " degree Celcius.")
print("The avarage data is rounded to two decimal places.")


# In[ ]:




